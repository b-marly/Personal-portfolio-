# Daniel Chukwuocha Portfolio Website

This is a simple personal portfolio website built using HTML, CSS (Bootstrap), and Font Awesome icons.

## Features
- About Me section
- Skills with icons
- Project gallery
- Contact button (email link)

## How to Use
1. Upload this folder to a GitHub repository.
2. Enable GitHub Pages in your repository settings.
3. Access your live portfolio via `https://your-username.github.io/portfolio/`.

---
© 2025 Daniel Chukwuocha. All rights reserved.
